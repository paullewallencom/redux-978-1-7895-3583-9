# mastering-redux
Mastering Redux [ Video], published by Packt
